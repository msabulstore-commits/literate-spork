# DMD Food Manager Pro — local PostgreSQL + installable PWA

A working starter upgrade built from the provided DMD Food Manager HTML. The original file is preserved in `legacy/`.

## Quick start
1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and replace both placeholder secrets.
3. Run `start-windows.bat` or `docker compose up -d --build`.
4. Open http://localhost:8080 and enter the `APP_API_KEY` in Settings.
5. Read `docs/INSTALL-WINDOWS.md` before Android/LAN deployment or real-data use.

## Architecture
- PostgreSQL 16 is the authoritative central store.
- FastAPI validates and posts stock/production transactions atomically.
- Responsive PWA caches its app shell and stores offline transaction submissions in IndexedDB.
- Idempotent event IDs help prevent duplicate posting on retry.

## Critical note
This is an implementation baseline, not yet a complete ERP replacement. It does not yet include the original app's full sales, delivery, payroll and accounting workflows. Do not replace the existing live workflow until migrations, accounting controls, role permissions, HTTPS and restore tests are complete.
