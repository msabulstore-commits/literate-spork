from contextlib import asynccontextmanager
from datetime import date, datetime
from decimal import Decimal
import json, os, uuid
from typing import Any
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

DB=os.environ['DATABASE_URL']
API_KEY=os.environ.get('APP_API_KEY','')
pool=ConnectionPool(DB, min_size=1, max_size=10, kwargs={"row_factory": dict_row}, open=False)
@asynccontextmanager
async def lifespan(app):
    pool.open(wait=True)
    yield
    pool.close()
app=FastAPI(title='DMD Food Manager API', version='2.0.0', lifespan=lifespan)
origins=[x.strip() for x in os.getenv('CORS_ORIGINS','*').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=['GET','POST','PUT','DELETE','OPTIONS'], allow_headers=['*'])

def auth(authorization: str|None=Header(default=None), x_api_key: str|None=Header(default=None)):
    supplied=x_api_key or ((authorization or '').removeprefix('Bearer ').strip())
    if not API_KEY or supplied != API_KEY: raise HTTPException(401,'Valid API key required')

def rowdict(row):
    if not row:return None
    return {k:(str(v) if isinstance(v,(Decimal,uuid.UUID)) else v.isoformat() if isinstance(v,(datetime,date)) else v) for k,v in row.items()}
def rowsdict(rows): return [rowdict(r) for r in rows]
def eid(v):
    try:return uuid.UUID(str(v))
    except Exception: raise HTTPException(422,'event_id must be a UUID')

class MaterialIn(BaseModel):
    sku: str|None=None; name: str=Field(min_length=1,max_length=160); unit: str='kg'; category: str='General';
    on_hand: Decimal=Decimal('0'); avg_cost: Decimal=Decimal('0'); reorder_level: Decimal=Decimal('0')
class ProductIn(BaseModel):
    sku: str|None=None; name: str=Field(min_length=1,max_length=160); category: str='General'; selling_price: Decimal=Decimal('0');
    batch_yield: Decimal=Decimal('1'); extra_cost_per_unit: Decimal=Decimal('0')
class RecipeIn(BaseModel): lines: list[dict[str,Any]]=Field(default_factory=list); effective_from: date|None=None
class PurchaseIn(BaseModel):
    event_id: str; material_id: str; quantity: Decimal=Field(gt=0); unit_price: Decimal=Field(ge=0); date: date|None=None; supplier: str|None=None; note: str|None=None; device_id: str='windows'
class WasteIn(BaseModel):
    event_id: str; material_id: str; quantity: Decimal=Field(gt=0); reason: str=Field(min_length=1); date: date|None=None; device_id: str='windows'
class ProductionIn(BaseModel):
    event_id: str; product_id: str; good_qty: Decimal=Field(gt=0); rejected_qty: Decimal=Decimal('0'); planned_qty: Decimal=Decimal('0');
    batch_code: str|None=None; material_usage: list[dict[str,Any]]|None=None; notes: str|None=None; date: datetime|None=None; device_id: str='windows'

@app.get('/health')
def health():
    try:
        with pool.connection() as c: c.execute('SELECT 1')
        return {'ok':True,'service':'dmd-food-api','database':'connected'}
    except Exception: raise HTTPException(503,'Database unavailable')
@app.get('/api/bootstrap', dependencies=[Depends(auth)])
def bootstrap():
    with pool.connection() as c:
        m=c.execute('SELECT * FROM materials WHERE active ORDER BY name').fetchall()
        p=c.execute('SELECT * FROM products WHERE active ORDER BY name').fetchall()
        return {'materials':rowsdict(m),'products':rowsdict(p),'server_time':datetime.now().astimezone().isoformat()}
@app.get('/api/dashboard', dependencies=[Depends(auth)])
def dashboard():
    with pool.connection() as c:
        mat=c.execute('SELECT count(*) AS item_count, coalesce(sum(on_hand*avg_cost),0) AS stock_value, count(*) FILTER(WHERE on_hand<=reorder_level) AS low_stock FROM materials WHERE active').fetchone()
        pr=c.execute("SELECT count(*) AS product_count FROM products WHERE active").fetchone()
        batches=c.execute("SELECT count(*) AS batch_count, coalesce(sum(good_qty),0) AS good_output, coalesce(sum(material_cost+extra_cost),0) AS production_cost FROM production_batches WHERE produced_at::date=CURRENT_DATE").fetchone()
        return {'materials':rowdict(mat),'products':rowdict(pr),'today_production':rowdict(batches)}
@app.get('/api/materials', dependencies=[Depends(auth)])
def materials():
    with pool.connection() as c:return rowsdict(c.execute('SELECT * FROM materials WHERE active ORDER BY name').fetchall())
@app.post('/api/materials', dependencies=[Depends(auth)])
def create_material(x:MaterialIn):
    if min(x.on_hand,x.avg_cost,x.reorder_level)<0: raise HTTPException(422,'Quantities and costs cannot be negative')
    with pool.connection() as c, c.transaction():
        r=c.execute('INSERT INTO materials(sku,name,unit,category,on_hand,avg_cost,reorder_level) VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING *',(x.sku.strip() or None,x.name.strip(),x.unit,x.category,x.on_hand,x.avg_cost,x.reorder_level)).fetchone()
        if x.on_hand>0:
            ev=uuid.uuid4(); c.execute("INSERT INTO stock_ledger(event_id,material_id,event_type,quantity_delta,unit_cost,reference,note) VALUES(%s,%s,'opening',%s,%s,'OPENING','Initial stock')",(ev,r['id'],x.on_hand,x.avg_cost))
        c.execute("INSERT INTO audit_log(action,entity_type,entity_id,after_data) VALUES('create','material',%s,%s)",(str(r['id']),json.dumps(rowdict(r))))
        return rowdict(r)
@app.get('/api/products', dependencies=[Depends(auth)])
def products():
    with pool.connection() as c:return rowsdict(c.execute('SELECT * FROM products WHERE active ORDER BY name').fetchall())
@app.post('/api/products', dependencies=[Depends(auth)])
def create_product(x:ProductIn):
    if min(x.selling_price,x.extra_cost_per_unit)<0 or x.batch_yield<=0: raise HTTPException(422,'Invalid product price, cost or batch yield')
    with pool.connection() as c, c.transaction():
        r=c.execute('INSERT INTO products(sku,name,category,selling_price,batch_yield,extra_cost_per_unit) VALUES(%s,%s,%s,%s,%s,%s) RETURNING *',(x.sku.strip() or None,x.name.strip(),x.category,x.selling_price,x.batch_yield,x.extra_cost_per_unit)).fetchone()
        c.execute("INSERT INTO audit_log(action,entity_type,entity_id,after_data) VALUES('create','product',%s,%s)",(str(r['id']),json.dumps(rowdict(r))))
        return rowdict(r)
@app.get('/api/products/{product_id}/recipe', dependencies=[Depends(auth)])
def get_recipe(product_id:str):
    with pool.connection() as c:
        r=c.execute("SELECT id,version,effective_from,status FROM recipes WHERE product_id=%s AND status='active' ORDER BY version DESC LIMIT 1",(product_id,)).fetchone()
        if not r:return {'recipe':None,'lines':[]}
        lines=c.execute('SELECT rl.material_id,m.name,m.unit,rl.quantity FROM recipe_lines rl JOIN materials m ON m.id=rl.material_id WHERE rl.recipe_id=%s ORDER BY m.name',(r['id'],)).fetchall()
        return {'recipe':rowdict(r),'lines':rowsdict(lines)}
@app.put('/api/products/{product_id}/recipe', dependencies=[Depends(auth)])
def set_recipe(product_id:str,x:RecipeIn):
    with pool.connection() as c, c.transaction():
        if not c.execute('SELECT id FROM products WHERE id=%s AND active',(product_id,)).fetchone():raise HTTPException(404,'Product not found')
        current=c.execute("SELECT coalesce(max(version),0) v FROM recipes WHERE product_id=%s",(product_id,)).fetchone()['v']
        c.execute("UPDATE recipes SET status='superseded' WHERE product_id=%s AND status='active'",(product_id,))
        rec=c.execute("INSERT INTO recipes(product_id,version,effective_from,status) VALUES(%s,%s,%s,'active') RETURNING *",(product_id,current+1,x.effective_from or date.today())).fetchone()
        seen=set()
        for line in x.lines:
            mid=str(line.get('material_id','')); qty=Decimal(str(line.get('quantity',0)))
            if mid in seen or qty<=0:raise HTTPException(422,'Recipe lines must have unique materials and positive quantities')
            seen.add(mid)
            c.execute('INSERT INTO recipe_lines(recipe_id,material_id,quantity) VALUES(%s,%s,%s)',(rec['id'],mid,qty))
        return {'recipe':rowdict(rec),'line_count':len(seen)}
@app.post('/api/transactions/purchase', dependencies=[Depends(auth)])
def purchase(x:PurchaseIn):
    event=eid(x.event_id)
    with pool.connection() as c, c.transaction():
        existing=c.execute('SELECT result FROM sync_events WHERE event_id=%s',(event,)).fetchone()
        if existing and existing['result']: return existing['result']
        m=c.execute('SELECT * FROM materials WHERE id=%s AND active FOR UPDATE',(x.material_id,)).fetchone()
        if not m:raise HTTPException(404,'Material not found')
        newq=m['on_hand']+x.quantity
        newcost=((m['on_hand']*m['avg_cost'])+(x.quantity*x.unit_price))/newq if newq>0 else x.unit_price
        c.execute('UPDATE materials SET on_hand=%s,avg_cost=%s,updated_at=now() WHERE id=%s',(newq,newcost,m['id']))
        c.execute("INSERT INTO stock_ledger(event_id,material_id,event_type,quantity_delta,unit_cost,reference,note,occurred_at,metadata) VALUES(%s,%s,'purchase',%s,%s,%s,%s,%s,%s)",(event,m['id'],x.quantity,x.unit_price,x.supplier,x.note,datetime.combine(x.date or date.today(),datetime.min.time()).astimezone().isoformat(),json.dumps({'supplier':x.supplier,'device_id':x.device_id})))
        result={'ok':True,'event_id':str(event),'material_id':str(m['id']),'on_hand':str(newq),'avg_cost':str(newcost)}
        c.execute("INSERT INTO sync_events(event_id,device_id,event_type,payload,status,result,applied_at) VALUES(%s,%s,'purchase',%s,'applied',%s,now()) ON CONFLICT(event_id) DO NOTHING",(event,x.device_id,x.model_dump_json(),json.dumps(result)))
        c.execute("INSERT INTO audit_log(event_id,action,entity_type,entity_id,after_data) VALUES(%s,'purchase','material',%s,%s)",(event,str(m['id']),json.dumps(result)))
        return result
@app.post('/api/transactions/waste', dependencies=[Depends(auth)])
def waste(x:WasteIn):
    event=eid(x.event_id)
    with pool.connection() as c, c.transaction():
        existing=c.execute('SELECT result FROM sync_events WHERE event_id=%s',(event,)).fetchone()
        if existing and existing['result']:return existing['result']
        m=c.execute('SELECT * FROM materials WHERE id=%s AND active FOR UPDATE',(x.material_id,)).fetchone()
        if not m:raise HTTPException(404,'Material not found')
        if x.quantity>m['on_hand']:raise HTTPException(409,f"Insufficient stock: available {m['on_hand']} {m['unit']}")
        newq=m['on_hand']-x.quantity;c.execute('UPDATE materials SET on_hand=%s,updated_at=now() WHERE id=%s',(newq,m['id']))
        c.execute("INSERT INTO stock_ledger(event_id,material_id,event_type,quantity_delta,unit_cost,reference,note,metadata) VALUES(%s,%s,'waste',%s,%s,%s,%s,%s)",(event,m['id'],-x.quantity,m['avg_cost'],x.reason,x.reason,json.dumps({'device_id':x.device_id})))
        result={'ok':True,'event_id':str(event),'on_hand':str(newq),'waste_value':str(x.quantity*m['avg_cost'])}
        c.execute("INSERT INTO sync_events(event_id,device_id,event_type,payload,status,result,applied_at) VALUES(%s,%s,'waste',%s,'applied',%s,now()) ON CONFLICT(event_id) DO NOTHING",(event,x.device_id,x.model_dump_json(),json.dumps(result)))
        c.execute("INSERT INTO audit_log(event_id,action,entity_type,entity_id,after_data) VALUES(%s,'waste','material',%s,%s)",(event,str(m['id']),json.dumps(result)))
        return result
@app.post('/api/transactions/production', dependencies=[Depends(auth)])
def production(x:ProductionIn):
    event=eid(x.event_id); batch=x.batch_code or ('DMD-'+event.hex[:12].upper())
    with pool.connection() as c, c.transaction():
        existing=c.execute('SELECT result FROM sync_events WHERE event_id=%s',(event,)).fetchone()
        if existing and existing['result']:return existing['result']
        p=c.execute('SELECT * FROM products WHERE id=%s AND active',(x.product_id,)).fetchone()
        if not p:raise HTTPException(404,'Product not found')
        rec=c.execute("SELECT * FROM recipes WHERE product_id=%s AND status='active' ORDER BY version DESC LIMIT 1",(p['id'],)).fetchone()
        if not rec and x.material_usage is None:
            raise HTTPException(422,'This product has no active recipe. Add a recipe or enter actual material usage.')
        if x.material_usage is not None:
            usage=x.material_usage
        elif rec:
            usage=[{'material_id':str(z['material_id']),'quantity':str(Decimal(z['quantity'])*x.good_qty/Decimal(p['batch_yield']))} for z in c.execute('SELECT material_id,quantity FROM recipe_lines WHERE recipe_id=%s',(rec['id'],)).fetchall()]
        else: usage=[]
        total=Decimal('0'); cost=Decimal('0'); checked=[]
        for u in usage:
            mid=str(u['material_id']); qty=Decimal(str(u['quantity']))
            if qty<=0:raise HTTPException(422,'Material usage must be positive')
            m=c.execute('SELECT * FROM materials WHERE id=%s AND active FOR UPDATE',(mid,)).fetchone()
            if not m:raise HTTPException(404,'Recipe material not found')
            if qty>m['on_hand']:raise HTTPException(409,f"Insufficient {m['name']}: available {m['on_hand']} {m['unit']}, required {qty}")
            checked.append((m,qty));total+=qty*m['avg_cost']
        for m,qty in checked:
            c.execute('UPDATE materials SET on_hand=on_hand-%s,updated_at=now() WHERE id=%s',(qty,m['id']))
            c.execute("INSERT INTO stock_ledger(event_id,material_id,event_type,quantity_delta,unit_cost,reference,note,metadata) VALUES(%s,%s,'production_issue',%s,%s,%s,%s,%s)",(uuid.uuid4(),m['id'],-qty,m['avg_cost'],batch,'Production material issue',json.dumps({'production_event_id':str(event)})))
        extra=x.good_qty*p['extra_cost_per_unit']
        c.execute('INSERT INTO production_batches(event_id,product_id,recipe_id,batch_code,planned_qty,good_qty,rejected_qty,material_cost,extra_cost,produced_at,notes) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',(event,p['id'],rec['id'] if rec else None,batch,x.planned_qty,x.good_qty,x.rejected_qty,total,extra,x.date or datetime.now(),x.notes))
        c.execute("INSERT INTO stock_ledger(event_id,product_id,event_type,quantity_delta,unit_cost,reference,note,occurred_at,metadata) VALUES(%s,%s,'production_output',%s,%s,%s,%s,%s,%s)",(uuid.uuid4(),p['id'],x.good_qty,(total+extra)/x.good_qty,batch,'Good finished-goods output',x.date or datetime.now(),json.dumps({'production_event_id':str(event),'rejected_qty':str(x.rejected_qty)})))
        result={'ok':True,'event_id':str(event),'batch_code':batch,'good_qty':str(x.good_qty),'material_cost':str(total),'extra_cost':str(extra),'unit_cost':str((total+extra)/x.good_qty)}
        c.execute("INSERT INTO sync_events(event_id,device_id,event_type,payload,status,result,applied_at) VALUES(%s,%s,'production',%s,'applied',%s,now()) ON CONFLICT(event_id) DO NOTHING",(event,x.device_id,x.model_dump_json(),json.dumps(result)))
        c.execute("INSERT INTO audit_log(event_id,action,entity_type,entity_id,after_data) VALUES(%s,'post','production_batch',%s,%s)",(event,batch,json.dumps(result)))
        return result
@app.get('/api/stock-ledger', dependencies=[Depends(auth)])
def ledger(limit:int=100):
    limit=max(1,min(limit,500))
    with pool.connection() as c:
        return rowsdict(c.execute("SELECT l.*,coalesce(m.name,p.name) item_name,coalesce(m.unit,'pcs') unit FROM stock_ledger l LEFT JOIN materials m ON m.id=l.material_id LEFT JOIN products p ON p.id=l.product_id ORDER BY occurred_at DESC LIMIT %s",(limit,)).fetchall())
@app.get('/api/production', dependencies=[Depends(auth)])
def production_list(limit:int=100):
    limit=max(1,min(limit,500))
    with pool.connection() as c:return rowsdict(c.execute('SELECT b.*,p.name product_name FROM production_batches b JOIN products p ON p.id=b.product_id ORDER BY produced_at DESC LIMIT %s',(limit,)).fetchall())
@app.get('/api/sync/status', dependencies=[Depends(auth)])
def sync_status():
    with pool.connection() as c:
        r=c.execute("SELECT count(*) FILTER(WHERE status='applied') applied,count(*) FILTER(WHERE status='rejected') rejected,max(applied_at) last_applied FROM sync_events").fetchone()
        return rowdict(r)
