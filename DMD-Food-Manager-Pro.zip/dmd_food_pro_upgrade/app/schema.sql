CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS materials (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), sku TEXT UNIQUE, name TEXT NOT NULL,
 unit TEXT NOT NULL DEFAULT 'kg', category TEXT NOT NULL DEFAULT 'General',
 on_hand NUMERIC(16,4) NOT NULL DEFAULT 0 CHECK (on_hand >= 0), avg_cost NUMERIC(16,4) NOT NULL DEFAULT 0 CHECK (avg_cost >= 0),
 reorder_level NUMERIC(16,4) NOT NULL DEFAULT 0 CHECK (reorder_level >= 0), active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS products (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), sku TEXT UNIQUE, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'General',
 selling_price NUMERIC(16,4) NOT NULL DEFAULT 0 CHECK (selling_price >= 0), batch_yield NUMERIC(16,4) NOT NULL DEFAULT 1 CHECK (batch_yield > 0),
 extra_cost_per_unit NUMERIC(16,4) NOT NULL DEFAULT 0 CHECK (extra_cost_per_unit >= 0), active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS recipes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), product_id UUID NOT NULL REFERENCES products(id), version INTEGER NOT NULL DEFAULT 1,
 effective_from DATE NOT NULL DEFAULT CURRENT_DATE, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','superseded','draft')),
 UNIQUE(product_id,version)
);
CREATE TABLE IF NOT EXISTS recipe_lines (
 recipe_id UUID NOT NULL REFERENCES recipes(id) ON DELETE CASCADE, material_id UUID NOT NULL REFERENCES materials(id),
 quantity NUMERIC(16,4) NOT NULL CHECK(quantity > 0), PRIMARY KEY(recipe_id,material_id)
);
CREATE TABLE IF NOT EXISTS stock_ledger (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), event_id UUID UNIQUE NOT NULL, material_id UUID REFERENCES materials(id), product_id UUID REFERENCES products(id),
 event_type TEXT NOT NULL CHECK(event_type IN ('opening','purchase','production_issue','production_output','waste','delivery','customer_return','adjustment','reversal')),
 quantity_delta NUMERIC(16,4) NOT NULL, unit_cost NUMERIC(16,4) NOT NULL DEFAULT 0, reference TEXT, note TEXT,
 occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(), created_by TEXT NOT NULL DEFAULT 'local-user', metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 CHECK ((material_id IS NOT NULL)::int + (product_id IS NOT NULL)::int = 1)
);
CREATE INDEX IF NOT EXISTS stock_ledger_material_date ON stock_ledger(material_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS stock_ledger_product_date ON stock_ledger(product_id, occurred_at DESC);
CREATE TABLE IF NOT EXISTS production_batches (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), event_id UUID UNIQUE NOT NULL, product_id UUID NOT NULL REFERENCES products(id),
 recipe_id UUID REFERENCES recipes(id), batch_code TEXT NOT NULL UNIQUE, planned_qty NUMERIC(16,4) NOT NULL DEFAULT 0,
 good_qty NUMERIC(16,4) NOT NULL CHECK(good_qty > 0), rejected_qty NUMERIC(16,4) NOT NULL DEFAULT 0 CHECK(rejected_qty >= 0),
 material_cost NUMERIC(16,4) NOT NULL DEFAULT 0, extra_cost NUMERIC(16,4) NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'posted',
 produced_at TIMESTAMPTZ NOT NULL DEFAULT now(), created_by TEXT NOT NULL DEFAULT 'local-user', notes TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGSERIAL PRIMARY KEY, event_id UUID, actor TEXT NOT NULL DEFAULT 'local-user', action TEXT NOT NULL, entity_type TEXT NOT NULL,
 entity_id TEXT, before_data JSONB, after_data JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sync_events (
 event_id UUID PRIMARY KEY, device_id TEXT NOT NULL, event_type TEXT NOT NULL, payload JSONB NOT NULL,
 status TEXT NOT NULL DEFAULT 'received' CHECK(status IN ('received','applied','rejected')), result JSONB, received_at TIMESTAMPTZ NOT NULL DEFAULT now(), applied_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
