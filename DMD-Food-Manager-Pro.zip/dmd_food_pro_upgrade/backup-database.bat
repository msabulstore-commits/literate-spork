@echo off
setlocal
cd /d "%~dp0"
if not exist backups mkdir backups
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set TS=%%i
for /f "tokens=2 delims==" %%i in ('findstr /b "POSTGRES_PASSWORD=" .env') do set PGPASSWORD=%%i
docker compose exec -T -e PGPASSWORD=%PGPASSWORD% db pg_dump -U dmd_app -d dmd_food -Fc > "backups\dmd-food-%TS%.dump"
if errorlevel 1 (echo Backup failed. & pause & exit /b 1)
echo Backup created: backups\dmd-food-%TS%.dump
pause
