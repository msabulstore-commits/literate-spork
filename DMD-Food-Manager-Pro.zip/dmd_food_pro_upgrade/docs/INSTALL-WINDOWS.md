# DMD Food Manager Pro — Windows installation

## What is in this package
- `web/`: responsive installable-PWA frontend with an offline app shell and IndexedDB transaction queue.
- `app/`: FastAPI business API, PostgreSQL schema and transactional stock/production operations.
- `docker-compose.yml`: local PostgreSQL + API + web server.
- `legacy/`: original DMD Food Manager HTML preserved as a reference; it is not connected to PostgreSQL.

## Windows setup
1. Install Docker Desktop for Windows and start it.
2. Copy `.env.example` to `.env` (or run `start-windows.bat` once to create it).
3. Edit `.env`. Replace `POSTGRES_PASSWORD` and `APP_API_KEY` with long, unique random values. Never share the file or commit it to source control.
4. Run `start-windows.bat`.
5. Open `http://localhost:8080`, then go to Settings and enter the same `APP_API_KEY` value.
6. Add material and product master records; set up recipes; test purchase, wastage and production before importing live records.

The API is published only through the web proxy. PostgreSQL is not exposed to the LAN. The database volume persists across restarts.

## Android PWA installation
A service worker/PWA requires a secure context. `http://localhost` works on the Windows computer, but `http://<windows-lan-ip>:8080` is not considered a secure context by Android browsers. For installation on Android, put the web service behind HTTPS using a trusted certificate and a LAN DNS name, or a private overlay network such as Tailscale Serve. Configure the HTTPS proxy to forward to `http://127.0.0.1:8080`; then open that HTTPS URL in Chrome on each Android device and choose **Install app** / **Add to Home screen**. Do not expose the app to the public internet without proper TLS, account-level authentication, authorization, rate limiting and security review.

## Offline behavior and important limits
- The application shell is cached for offline launch.
- Purchase, wastage and production submissions can be queued in each browser's IndexedDB when the server is unreachable. A queued transaction is not yet committed to PostgreSQL until synchronization succeeds.
- Material/product creation and recipe editing currently require server connectivity.
- Each device's offline stock view is a cached snapshot. It cannot guarantee shared real-time stock while disconnected. On synchronization, insufficient stock and conflicting transactions are rejected/flagged rather than silently accepted.
- The current transaction API uses a shared API key. This is a controlled pilot setup, not a finished per-user identity/role system.

## Backup and restore
Run `backup-database.bat` to write a PostgreSQL custom-format dump to `backups/`. Keep copies on a separate disk. A backup is only trustworthy after you periodically restore it into a test database and verify counts and balances. Do not delete the Docker volume as a backup strategy.

Example manual restore (STOP the app first, and restore only into the intended database):
```powershell
docker compose stop api
# Restore procedure should be tested on a separate database first.
# docker compose exec -T db pg_restore -U dmd_app -d dmd_food --clean --if-exists < backups\your-backup.dump
docker compose start api
```

## Updating
Back up first, then run `docker compose up -d --build`. Schema changes should be delivered as explicit, versioned migrations; do not edit an already-deployed initial schema and assume existing databases will be altered.

## Current scope
Implemented: material/product masters, recipes with versions, purchases, wastage, production posting, material stock ledger, dashboard, local shell caching, offline transaction queue, API key check, basic audit trail, Docker-based local deployment.
Not yet implemented: sales/delivery/customer collection, supplier payables, payroll, full double-entry accounting, multi-user permissions, barcode/lot/expiry traceability, finished-goods movement/delivery, formal reversal workflows, guided Excel import, and per-user device identity. Keep the original HTML and Excel files as the historical reference until migration has been reconciled.
