# Source-file audit and migration controls

## Source assets preserved
- `legacy/DMD-Food-Manager-original.html` is an unchanged copy of the provided 73 KB HTML source.
- Original Excel files were inspected but are not silently imported into the new database. Preserve them separately until totals are reconciled.

## Findings from the existing HTML source
- Browser state is stored under `localStorage` key `dmd_food_v1`; the new API does not automatically see that data.
- `save()` suppresses storage exceptions, so the old app can fail to persist without an obvious user-facing error.
- `cost()` computes recipe cost from current material rates; historic margin calculations can therefore move when current rates/recipes change.
- `buy()`, `wst()` and `ssave()` directly mutate and save application state outside the `tx()` wrapper used by some accounting-sensitive paths.
- Production and product editing use mutable recipe/material data; posted batch snapshots and formal reversal workflows are needed to preserve historical cost and auditability.
- The legacy interface says data is saved in the current browser only. It is not a multi-device database or synchronization system.

## Findings from the supplied Excel workbooks
- `Product Stock-18.9.26.xlsx`: 20 worksheets, dated daily sheets, with a mixture of older and newer column layouts. The last few names include `14.10.2026`, `New 16.10.24`, and `17.10.26`; `New 16.10.24` is a date-name inconsistency in the October 2026 sequence and should be verified with the business owner.
- Formula review identified a duplicated reference in at least one production-cost formula pattern (including an `AM`-column formula on the 27 September sheet). Verify the intended product-column mapping before correcting historical totals.
- `18-09-26.xlsx`: 20 daily/period sheets with changing date/name conventions and wide multi-person delivery sections. Import must identify the actual salesman and product columns per sheet rather than assume one fixed layout.
- `salary sheet.xlsx`: September and October 2026 sheets use different row arrangements. The workbook's daily salary calculation uses a 30-day divisor; confirm the intended salary policy before migrating payroll.

## Required migration sequence
1. Export a fresh JSON backup from the legacy HTML application using its Backup action. The browser's `localStorage` is not present in the HTML source file itself.
2. Create a mapping table for materials, products, employees, customers, suppliers and salespersons. Match on reviewed IDs/codes, not just display names.
3. Normalize units (kg/g, litre/ml, pieces/pack) and verify conversion factors before importing quantities.
4. Import verified opening balances with a cutover date. Keep old transaction history in a separate archive unless it can be imported and reconciled at transaction grain.
5. Reconcile material stock value, finished stock, customer/supplier balances, payroll payable and cash/bank balances against signed-off source reports.
6. Run the test cases in `docs/INSTALL-WINDOWS.md` and obtain business-owner sign-off before using the new system for live posting.

## Non-negotiable accounting/stock controls before live rollout
- No silent save failures; transaction failures must be visible and leave no partial stock or accounting effects.
- Every stock movement has a unique event ID and immutable ledger row; retries must be idempotent.
- Historical recipe version, actual consumption, material cost and output are stored with each posted production batch.
- Finished-goods delivery/return, customer receivable, supplier payable, cash/bank and payroll posting must be implemented and reconciled before the system replaces the old application.
- Test restore into a separate database and compare row counts, stock totals and accounting totals.
