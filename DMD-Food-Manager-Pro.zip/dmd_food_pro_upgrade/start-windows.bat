@echo off
setlocal
cd /d "%~dp0"
where docker >nul 2>nul
if errorlevel 1 (
  echo Docker Desktop is required. Install it, start Docker Desktop, then run this file again.
  pause
  exit /b 1
)
if not exist .env (
  copy .env.example .env >nul
  echo.
  echo Created .env from template. STOP: open .env and replace both placeholder secrets before continuing.
  echo Then run start-windows.bat again.
  notepad .env
  pause
  exit /b 1
)
echo Starting DMD Food Manager Pro services...
docker compose up -d --build
if errorlevel 1 (
  echo Startup failed. Check the messages above and docs\INSTALL-WINDOWS.md.
  pause
  exit /b 1
)
echo.
echo App URL: http://localhost:8080
 echo API health: http://localhost:8080/health
 echo To access from Android on your LAN, configure HTTPS as documented in docs\INSTALL-WINDOWS.md.
start http://localhost:8080
pause
